===================================
   Generic Futuristic muscle car
===================================

Version: 1.1
Author: LagzDesign

📦 Description:
-----------------------
Generic Concept Muscle car, with a futuristic and modern design, game ready model Great for your games, renders or animations

📁 Package Contents:
-----------------------
- Vehicle Model with wheels
- 2 Textures

🔧 Features:
----------------------
- Game ready Model, well optimized
- Model uses materials which can be customized
- 3 Model formats
- No trade marks

📥 Installation:
----------------------
1. Download all the .zip file from the page
2. Extract the files into a folder
3. Open or import the Models into your Game Engine or 3D software
4. Apply textures or materials (download the additional file)

📌 Requirements:
----------------------
- This model should work with any game engine or 3d software, make sure to import the correct format


📝 Changelog: 1.1
-------------
- Added Interior to the vehicle
- Added Exhaust 
- Updated the tire texture

🔗 Support:
-----------
If you have any issues, suggestions, or questions:
- Discord server: https://discord.gg/pN3rYKuZ
- Website: https://lagzsite.carrd.co/

Enjoy!